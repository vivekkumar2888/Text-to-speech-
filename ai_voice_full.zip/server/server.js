
import express from "express";
import fetch from "node-fetch";
import dotenv from "dotenv";
import cors from "cors";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const ELEVEN_KEY = process.env.ELEVEN_API_KEY;

app.get("/voices", async (req,res)=>{
  const r = await fetch("https://api.elevenlabs.io/v1/voices",{
    headers:{ "xi-api-key": ELEVEN_KEY }
  });
  const j = await r.json();
  res.json(j.voices || []);
});

app.post("/tts", async (req,res)=>{
  const {text,voice} = req.body;
  const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice}`,{
    method:"POST",
    headers:{
      "xi-api-key": ELEVEN_KEY,
      "Content-Type":"application/json"
    },
    body:JSON.stringify({
      text,
      voice_settings:{stability:0.4,similarity_boost:0.7}
    })
  });
  const buf = await r.arrayBuffer();
  res.setHeader("Content-Type","audio/mpeg");
  res.send(Buffer.from(buf));
});

app.listen(3000,()=>console.log("Server running on 3000"));
